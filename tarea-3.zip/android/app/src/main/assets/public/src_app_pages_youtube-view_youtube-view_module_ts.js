"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_youtube-view_youtube-view_module_ts"],{

/***/ 5919:
/*!****************************************************************************!*\
  !*** ./node_modules/rxjs/_esm2015/internal/observable/fromEventPattern.js ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "fromEventPattern": () => (/* binding */ fromEventPattern)
/* harmony export */ });
/* harmony import */ var _Observable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Observable */ 1590);
/* harmony import */ var _util_isArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../util/isArray */ 9845);
/* harmony import */ var _util_isFunction__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../util/isFunction */ 8357);
/* harmony import */ var _operators_map__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../operators/map */ 8377);




function fromEventPattern(addHandler, removeHandler, resultSelector) {
    if (resultSelector) {
        return fromEventPattern(addHandler, removeHandler).pipe((0,_operators_map__WEBPACK_IMPORTED_MODULE_0__.map)(args => (0,_util_isArray__WEBPACK_IMPORTED_MODULE_1__.isArray)(args) ? resultSelector(...args) : resultSelector(args)));
    }
    return new _Observable__WEBPACK_IMPORTED_MODULE_2__.Observable(subscriber => {
        const handler = (...e) => subscriber.next(e.length === 1 ? e[0] : e);
        let retValue;
        try {
            retValue = addHandler(handler);
        }
        catch (err) {
            subscriber.error(err);
            return undefined;
        }
        if (!(0,_util_isFunction__WEBPACK_IMPORTED_MODULE_3__.isFunction)(removeHandler)) {
            return undefined;
        }
        return () => removeHandler(handler, retValue);
    });
}


/***/ }),

/***/ 5088:
/*!************************************************************************!*\
  !*** ./node_modules/rxjs/_esm2015/internal/operators/combineLatest.js ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "combineLatest": () => (/* binding */ combineLatest)
/* harmony export */ });
/* harmony import */ var _util_isArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util/isArray */ 9845);
/* harmony import */ var _observable_combineLatest__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../observable/combineLatest */ 2890);
/* harmony import */ var _observable_from__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../observable/from */ 4126);



const none = {};
function combineLatest(...observables) {
    let project = null;
    if (typeof observables[observables.length - 1] === 'function') {
        project = observables.pop();
    }
    if (observables.length === 1 && (0,_util_isArray__WEBPACK_IMPORTED_MODULE_0__.isArray)(observables[0])) {
        observables = observables[0].slice();
    }
    return (source) => source.lift.call((0,_observable_from__WEBPACK_IMPORTED_MODULE_1__.from)([source, ...observables]), new _observable_combineLatest__WEBPACK_IMPORTED_MODULE_2__.CombineLatestOperator(project));
}


/***/ }),

/***/ 4194:
/*!******************************************************************!*\
  !*** ./node_modules/rxjs/_esm2015/internal/operators/publish.js ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "publish": () => (/* binding */ publish)
/* harmony export */ });
/* harmony import */ var _Subject__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Subject */ 4008);
/* harmony import */ var _multicast__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./multicast */ 6966);


function publish(selector) {
    return selector ?
        (0,_multicast__WEBPACK_IMPORTED_MODULE_0__.multicast)(() => new _Subject__WEBPACK_IMPORTED_MODULE_1__.Subject(), selector) :
        (0,_multicast__WEBPACK_IMPORTED_MODULE_0__.multicast)(new _Subject__WEBPACK_IMPORTED_MODULE_1__.Subject());
}


/***/ }),

/***/ 5033:
/*!********************************************************************!*\
  !*** ./node_modules/rxjs/_esm2015/internal/operators/skipWhile.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "skipWhile": () => (/* binding */ skipWhile)
/* harmony export */ });
/* harmony import */ var _Subscriber__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../Subscriber */ 8412);

function skipWhile(predicate) {
    return (source) => source.lift(new SkipWhileOperator(predicate));
}
class SkipWhileOperator {
    constructor(predicate) {
        this.predicate = predicate;
    }
    call(subscriber, source) {
        return source.subscribe(new SkipWhileSubscriber(subscriber, this.predicate));
    }
}
class SkipWhileSubscriber extends _Subscriber__WEBPACK_IMPORTED_MODULE_0__.Subscriber {
    constructor(destination, predicate) {
        super(destination);
        this.predicate = predicate;
        this.skipping = true;
        this.index = 0;
    }
    _next(value) {
        const destination = this.destination;
        if (this.skipping) {
            this.tryCallPredicate(value);
        }
        if (!this.skipping) {
            destination.next(value);
        }
    }
    tryCallPredicate(value) {
        try {
            const result = this.predicate(value, this.index++);
            this.skipping = Boolean(result);
        }
        catch (err) {
            this.destination.error(err);
        }
    }
}


/***/ }),

/***/ 4058:
/*!********************************************************************!*\
  !*** ./node_modules/rxjs/_esm2015/internal/operators/takeUntil.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "takeUntil": () => (/* binding */ takeUntil)
/* harmony export */ });
/* harmony import */ var _innerSubscribe__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../innerSubscribe */ 6042);

function takeUntil(notifier) {
    return (source) => source.lift(new TakeUntilOperator(notifier));
}
class TakeUntilOperator {
    constructor(notifier) {
        this.notifier = notifier;
    }
    call(subscriber, source) {
        const takeUntilSubscriber = new TakeUntilSubscriber(subscriber);
        const notifierSubscription = (0,_innerSubscribe__WEBPACK_IMPORTED_MODULE_0__.innerSubscribe)(this.notifier, new _innerSubscribe__WEBPACK_IMPORTED_MODULE_0__.SimpleInnerSubscriber(takeUntilSubscriber));
        if (notifierSubscription && !takeUntilSubscriber.seenValue) {
            takeUntilSubscriber.add(notifierSubscription);
            return source.subscribe(takeUntilSubscriber);
        }
        return takeUntilSubscriber;
    }
}
class TakeUntilSubscriber extends _innerSubscribe__WEBPACK_IMPORTED_MODULE_0__.SimpleOuterSubscriber {
    constructor(destination) {
        super(destination);
        this.seenValue = false;
    }
    notifyNext() {
        this.seenValue = true;
        this.complete();
    }
    notifyComplete() {
    }
}


/***/ }),

/***/ 7509:
/*!*************************************************************************!*\
  !*** ./node_modules/rxjs/_esm2015/internal/operators/withLatestFrom.js ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "withLatestFrom": () => (/* binding */ withLatestFrom)
/* harmony export */ });
/* harmony import */ var _OuterSubscriber__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../OuterSubscriber */ 218);
/* harmony import */ var _util_subscribeToResult__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../util/subscribeToResult */ 9230);


function withLatestFrom(...args) {
    return (source) => {
        let project;
        if (typeof args[args.length - 1] === 'function') {
            project = args.pop();
        }
        const observables = args;
        return source.lift(new WithLatestFromOperator(observables, project));
    };
}
class WithLatestFromOperator {
    constructor(observables, project) {
        this.observables = observables;
        this.project = project;
    }
    call(subscriber, source) {
        return source.subscribe(new WithLatestFromSubscriber(subscriber, this.observables, this.project));
    }
}
class WithLatestFromSubscriber extends _OuterSubscriber__WEBPACK_IMPORTED_MODULE_0__.OuterSubscriber {
    constructor(destination, observables, project) {
        super(destination);
        this.observables = observables;
        this.project = project;
        this.toRespond = [];
        const len = observables.length;
        this.values = new Array(len);
        for (let i = 0; i < len; i++) {
            this.toRespond.push(i);
        }
        for (let i = 0; i < len; i++) {
            let observable = observables[i];
            this.add((0,_util_subscribeToResult__WEBPACK_IMPORTED_MODULE_1__.subscribeToResult)(this, observable, undefined, i));
        }
    }
    notifyNext(_outerValue, innerValue, outerIndex) {
        this.values[outerIndex] = innerValue;
        const toRespond = this.toRespond;
        if (toRespond.length > 0) {
            const found = toRespond.indexOf(outerIndex);
            if (found !== -1) {
                toRespond.splice(found, 1);
            }
        }
    }
    notifyComplete() {
    }
    _next(value) {
        if (this.toRespond.length === 0) {
            const args = [value, ...this.values];
            if (this.project) {
                this._tryProject(args);
            }
            else {
                this.destination.next(args);
            }
        }
    }
    _tryProject(args) {
        let result;
        try {
            result = this.project.apply(this, args);
        }
        catch (err) {
            this.destination.error(err);
            return;
        }
        this.destination.next(result);
    }
}


/***/ }),

/***/ 9140:
/*!*******************************************************************!*\
  !*** ./src/app/pages/youtube-view/youtube-view-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "YoutubeViewPageRoutingModule": () => (/* binding */ YoutubeViewPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _youtube_view_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./youtube-view.page */ 2333);




const routes = [
    {
        path: '',
        component: _youtube_view_page__WEBPACK_IMPORTED_MODULE_0__.YoutubeViewPage
    }
];
let YoutubeViewPageRoutingModule = class YoutubeViewPageRoutingModule {
};
YoutubeViewPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], YoutubeViewPageRoutingModule);



/***/ }),

/***/ 3530:
/*!***********************************************************!*\
  !*** ./src/app/pages/youtube-view/youtube-view.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "YoutubeViewPageModule": () => (/* binding */ YoutubeViewPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8346);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 8099);
/* harmony import */ var _youtube_view_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./youtube-view-routing.module */ 9140);
/* harmony import */ var _youtube_view_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./youtube-view.page */ 2333);
/* harmony import */ var _angular_youtube_player__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/youtube-player */ 3904);








let YoutubeViewPageModule = class YoutubeViewPageModule {
};
YoutubeViewPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _angular_youtube_player__WEBPACK_IMPORTED_MODULE_7__.YouTubePlayerModule,
            _youtube_view_routing_module__WEBPACK_IMPORTED_MODULE_0__.YoutubeViewPageRoutingModule
        ],
        declarations: [_youtube_view_page__WEBPACK_IMPORTED_MODULE_1__.YoutubeViewPage]
    })
], YoutubeViewPageModule);



/***/ }),

/***/ 2333:
/*!*********************************************************!*\
  !*** ./src/app/pages/youtube-view/youtube-view.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "YoutubeViewPage": () => (/* binding */ YoutubeViewPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _C_Users_Samy_Desktop_Pruebas_ionic_tarea_3_node_modules_ngtools_webpack_src_loaders_direct_resource_js_youtube_view_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./youtube-view.page.html */ 6483);
/* harmony import */ var _youtube_view_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./youtube-view.page.scss */ 5255);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment */ 8260);





let YoutubeViewPage = class YoutubeViewPage {
    constructor() {
        this.idVideo = src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.idVideo;
    }
    ngOnInit() {
        const tag = document.createElement('script');
        tag.src = 'https://www.youtube.com/iframe_api';
        document.body.appendChild(tag);
    }
    invokeVideoPlayer() {
    }
};
YoutubeViewPage.ctorParameters = () => [];
YoutubeViewPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-youtube-view',
        template: _C_Users_Samy_Desktop_Pruebas_ionic_tarea_3_node_modules_ngtools_webpack_src_loaders_direct_resource_js_youtube_view_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_youtube_view_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], YoutubeViewPage);



/***/ }),

/***/ 6483:
/*!**************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/youtube-view/youtube-view.page.html ***!
  \**************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header [translucent]=\"true\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Experiencia</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n  <ion-header collapse=\"condense\">\n    <ion-toolbar>\n      <ion-title size=\"large\">Experiencia</ion-title>\n    </ion-toolbar>\n  </ion-header>\n\n  <div class=\"content\">\n    <div class=\"video\">\n      <youtube-player [videoId]=\"idVideo\" [width]=\"400\"></youtube-player>\n    </div>\n  </div>\n</ion-content>\n");

/***/ }),

/***/ 5255:
/*!***********************************************************!*\
  !*** ./src/app/pages/youtube-view/youtube-view.page.scss ***!
  \***********************************************************/
/***/ ((module) => {

module.exports = ".video {\n  position: absolute;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\nyoutube-player {\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInlvdXR1YmUtdmlldy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxrQkFBQTtFQUNBLFFBQUE7RUFDQSwyQkFBQTtBQUNKOztBQUVBO0VBQ0ksV0FBQTtBQUNKIiwiZmlsZSI6InlvdXR1YmUtdmlldy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudmlkZW97XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDUwJTtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtNTAlKTtcclxufVxyXG5cclxueW91dHViZS1wbGF5ZXJ7XHJcbiAgICB3aWR0aDogMTAwJTtcclxufSJdfQ== */";

/***/ }),

/***/ 3904:
/*!**************************************************************************!*\
  !*** ./node_modules/@angular/youtube-player/fesm2020/youtube-player.mjs ***!
  \**************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "YouTubePlayer": () => (/* binding */ YouTubePlayer),
/* harmony export */   "YouTubePlayerModule": () => (/* binding */ YouTubePlayerModule)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 8267);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 4008);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 1119);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 8252);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 5919);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ 1590);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs */ 2890);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! rxjs */ 1755);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! rxjs */ 4850);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 6928);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 4172);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 5029);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 4058);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 4194);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ 9026);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs/operators */ 758);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs/operators */ 7509);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! rxjs/operators */ 8377);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! rxjs/operators */ 9990);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! rxjs/operators */ 8785);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! rxjs/operators */ 5088);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! rxjs/operators */ 5033);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! rxjs/operators */ 8027);




 /// <reference types="youtube" />

const _c0 = ["youtubeContainer"];
const DEFAULT_PLAYER_WIDTH = 640;
const DEFAULT_PLAYER_HEIGHT = 390;
/**
 * Angular component that renders a YouTube player via the YouTube player
 * iframe API.
 * @see https://developers.google.com/youtube/iframe_api_reference
 */

class YouTubePlayer {
  constructor(_ngZone, platformId) {
    this._ngZone = _ngZone;
    this._youtubeContainer = new rxjs__WEBPACK_IMPORTED_MODULE_0__.Subject();
    this._destroyed = new rxjs__WEBPACK_IMPORTED_MODULE_0__.Subject();
    this._playerChanges = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(undefined);
    this._videoId = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(undefined);
    this._height = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(DEFAULT_PLAYER_HEIGHT);
    this._width = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(DEFAULT_PLAYER_WIDTH);
    this._startSeconds = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(undefined);
    this._endSeconds = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(undefined);
    this._suggestedQuality = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(undefined);
    this._playerVars = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(undefined);
    /** Outputs are direct proxies from the player itself. */

    this.ready = this._getLazyEmitter('onReady');
    this.stateChange = this._getLazyEmitter('onStateChange');
    this.error = this._getLazyEmitter('onError');
    this.apiChange = this._getLazyEmitter('onApiChange');
    this.playbackQualityChange = this._getLazyEmitter('onPlaybackQualityChange');
    this.playbackRateChange = this._getLazyEmitter('onPlaybackRateChange');
    this._isBrowser = (0,_angular_common__WEBPACK_IMPORTED_MODULE_2__.isPlatformBrowser)(platformId);
  }
  /** YouTube Video ID to view */


  get videoId() {
    return this._videoId.value;
  }

  set videoId(videoId) {
    this._videoId.next(videoId);
  }
  /** Height of video player */


  get height() {
    return this._height.value;
  }

  set height(height) {
    this._height.next(height || DEFAULT_PLAYER_HEIGHT);
  }
  /** Width of video player */


  get width() {
    return this._width.value;
  }

  set width(width) {
    this._width.next(width || DEFAULT_PLAYER_WIDTH);
  }
  /** The moment when the player is supposed to start playing */


  set startSeconds(startSeconds) {
    this._startSeconds.next(startSeconds);
  }
  /** The moment when the player is supposed to stop playing */


  set endSeconds(endSeconds) {
    this._endSeconds.next(endSeconds);
  }
  /** The suggested quality of the player */


  set suggestedQuality(suggestedQuality) {
    this._suggestedQuality.next(suggestedQuality);
  }
  /**
   * Extra parameters used to configure the player. See:
   * https://developers.google.com/youtube/player_parameters.html?playerVersion=HTML5#Parameters
   */


  get playerVars() {
    return this._playerVars.value;
  }

  set playerVars(playerVars) {
    this._playerVars.next(playerVars);
  }

  ngOnInit() {
    // Don't do anything if we're not in a browser environment.
    if (!this._isBrowser) {
      return;
    }

    let iframeApiAvailableObs = (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.of)(true);

    if (!window.YT || !window.YT.Player) {
      if (this.showBeforeIframeApiLoads && (typeof ngDevMode === 'undefined' || ngDevMode)) {
        throw new Error('Namespace YT not found, cannot construct embedded youtube player. ' + 'Please install the YouTube Player API Reference for iframe Embeds: ' + 'https://developers.google.com/youtube/iframe_api_reference');
      }

      const iframeApiAvailableSubject = new rxjs__WEBPACK_IMPORTED_MODULE_0__.Subject();
      this._existingApiReadyCallback = window.onYouTubeIframeAPIReady;

      window.onYouTubeIframeAPIReady = () => {
        if (this._existingApiReadyCallback) {
          this._existingApiReadyCallback();
        }

        this._ngZone.run(() => iframeApiAvailableSubject.next(true));
      };

      iframeApiAvailableObs = iframeApiAvailableSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.take)(1), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.startWith)(false));
    } // An observable of the currently loaded player.


    const playerObs = createPlayerObservable(this._youtubeContainer, this._videoId, iframeApiAvailableObs, this._width, this._height, this._playerVars, this._ngZone).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.tap)(player => {
      // Emit this before the `waitUntilReady` call so that we can bind to
      // events that happen as the player is being initialized (e.g. `onReady`).
      this._playerChanges.next(player);
    }), waitUntilReady(player => {
      // Destroy the player if loading was aborted so that we don't end up leaking memory.
      if (!playerIsReady(player)) {
        player.destroy();
      }
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.takeUntil)(this._destroyed), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.publish)()); // Set up side effects to bind inputs to the player.

    playerObs.subscribe(player => {
      this._player = player;

      if (player && this._pendingPlayerState) {
        this._initializePlayer(player, this._pendingPlayerState);
      }

      this._pendingPlayerState = undefined;
    });
    bindSizeToPlayer(playerObs, this._width, this._height);
    bindSuggestedQualityToPlayer(playerObs, this._suggestedQuality);
    bindCueVideoCall(playerObs, this._videoId, this._startSeconds, this._endSeconds, this._suggestedQuality, this._destroyed); // After all of the subscriptions are set up, connect the observable.

    playerObs.connect();
  }

  ngAfterViewInit() {
    this._youtubeContainer.next(this.youtubeContainer.nativeElement);
  }

  ngOnDestroy() {
    if (this._player) {
      this._player.destroy();

      window.onYouTubeIframeAPIReady = this._existingApiReadyCallback;
    }

    this._playerChanges.complete();

    this._videoId.complete();

    this._height.complete();

    this._width.complete();

    this._startSeconds.complete();

    this._endSeconds.complete();

    this._suggestedQuality.complete();

    this._youtubeContainer.complete();

    this._playerVars.complete();

    this._destroyed.next();

    this._destroyed.complete();
  }
  /** See https://developers.google.com/youtube/iframe_api_reference#playVideo */


  playVideo() {
    if (this._player) {
      this._player.playVideo();
    } else {
      this._getPendingState().playbackState = YT.PlayerState.PLAYING;
    }
  }
  /** See https://developers.google.com/youtube/iframe_api_reference#pauseVideo */


  pauseVideo() {
    if (this._player) {
      this._player.pauseVideo();
    } else {
      this._getPendingState().playbackState = YT.PlayerState.PAUSED;
    }
  }
  /** See https://developers.google.com/youtube/iframe_api_reference#stopVideo */


  stopVideo() {
    if (this._player) {
      this._player.stopVideo();
    } else {
      // It seems like YouTube sets the player to CUED when it's stopped.
      this._getPendingState().playbackState = YT.PlayerState.CUED;
    }
  }
  /** See https://developers.google.com/youtube/iframe_api_reference#seekTo */


  seekTo(seconds, allowSeekAhead) {
    if (this._player) {
      this._player.seekTo(seconds, allowSeekAhead);
    } else {
      this._getPendingState().seek = {
        seconds,
        allowSeekAhead
      };
    }
  }
  /** See https://developers.google.com/youtube/iframe_api_reference#mute */


  mute() {
    if (this._player) {
      this._player.mute();
    } else {
      this._getPendingState().muted = true;
    }
  }
  /** See https://developers.google.com/youtube/iframe_api_reference#unMute */


  unMute() {
    if (this._player) {
      this._player.unMute();
    } else {
      this._getPendingState().muted = false;
    }
  }
  /** See https://developers.google.com/youtube/iframe_api_reference#isMuted */


  isMuted() {
    if (this._player) {
      return this._player.isMuted();
    }

    if (this._pendingPlayerState) {
      return !!this._pendingPlayerState.muted;
    }

    return false;
  }
  /** See https://developers.google.com/youtube/iframe_api_reference#setVolume */


  setVolume(volume) {
    if (this._player) {
      this._player.setVolume(volume);
    } else {
      this._getPendingState().volume = volume;
    }
  }
  /** See https://developers.google.com/youtube/iframe_api_reference#getVolume */


  getVolume() {
    if (this._player) {
      return this._player.getVolume();
    }

    if (this._pendingPlayerState && this._pendingPlayerState.volume != null) {
      return this._pendingPlayerState.volume;
    }

    return 0;
  }
  /** See https://developers.google.com/youtube/iframe_api_reference#setPlaybackRate */


  setPlaybackRate(playbackRate) {
    if (this._player) {
      return this._player.setPlaybackRate(playbackRate);
    } else {
      this._getPendingState().playbackRate = playbackRate;
    }
  }
  /** See https://developers.google.com/youtube/iframe_api_reference#getPlaybackRate */


  getPlaybackRate() {
    if (this._player) {
      return this._player.getPlaybackRate();
    }

    if (this._pendingPlayerState && this._pendingPlayerState.playbackRate != null) {
      return this._pendingPlayerState.playbackRate;
    }

    return 0;
  }
  /** See https://developers.google.com/youtube/iframe_api_reference#getAvailablePlaybackRates */


  getAvailablePlaybackRates() {
    return this._player ? this._player.getAvailablePlaybackRates() : [];
  }
  /** See https://developers.google.com/youtube/iframe_api_reference#getVideoLoadedFraction */


  getVideoLoadedFraction() {
    return this._player ? this._player.getVideoLoadedFraction() : 0;
  }
  /** See https://developers.google.com/youtube/iframe_api_reference#getPlayerState */


  getPlayerState() {
    if (!this._isBrowser || !window.YT) {
      return undefined;
    }

    if (this._player) {
      return this._player.getPlayerState();
    }

    if (this._pendingPlayerState && this._pendingPlayerState.playbackState != null) {
      return this._pendingPlayerState.playbackState;
    }

    return YT.PlayerState.UNSTARTED;
  }
  /** See https://developers.google.com/youtube/iframe_api_reference#getCurrentTime */


  getCurrentTime() {
    if (this._player) {
      return this._player.getCurrentTime();
    }

    if (this._pendingPlayerState && this._pendingPlayerState.seek) {
      return this._pendingPlayerState.seek.seconds;
    }

    return 0;
  }
  /** See https://developers.google.com/youtube/iframe_api_reference#getPlaybackQuality */


  getPlaybackQuality() {
    return this._player ? this._player.getPlaybackQuality() : 'default';
  }
  /** See https://developers.google.com/youtube/iframe_api_reference#getAvailableQualityLevels */


  getAvailableQualityLevels() {
    return this._player ? this._player.getAvailableQualityLevels() : [];
  }
  /** See https://developers.google.com/youtube/iframe_api_reference#getDuration */


  getDuration() {
    return this._player ? this._player.getDuration() : 0;
  }
  /** See https://developers.google.com/youtube/iframe_api_reference#getVideoUrl */


  getVideoUrl() {
    return this._player ? this._player.getVideoUrl() : '';
  }
  /** See https://developers.google.com/youtube/iframe_api_reference#getVideoEmbedCode */


  getVideoEmbedCode() {
    return this._player ? this._player.getVideoEmbedCode() : '';
  }
  /** Gets an object that should be used to store the temporary API state. */


  _getPendingState() {
    if (!this._pendingPlayerState) {
      this._pendingPlayerState = {};
    }

    return this._pendingPlayerState;
  }
  /** Initializes a player from a temporary state. */


  _initializePlayer(player, state) {
    const {
      playbackState,
      playbackRate,
      volume,
      muted,
      seek
    } = state;

    switch (playbackState) {
      case YT.PlayerState.PLAYING:
        player.playVideo();
        break;

      case YT.PlayerState.PAUSED:
        player.pauseVideo();
        break;

      case YT.PlayerState.CUED:
        player.stopVideo();
        break;
    }

    if (playbackRate != null) {
      player.setPlaybackRate(playbackRate);
    }

    if (volume != null) {
      player.setVolume(volume);
    }

    if (muted != null) {
      muted ? player.mute() : player.unMute();
    }

    if (seek != null) {
      player.seekTo(seek.seconds, seek.allowSeekAhead);
    }
  }
  /** Gets an observable that adds an event listener to the player when a user subscribes to it. */


  _getLazyEmitter(name) {
    // Start with the stream of players. This way the events will be transferred
    // over to the new player if it gets swapped out under-the-hood.
    return this._playerChanges.pipe( // Switch to the bound event. `switchMap` ensures that the old event is removed when the
    // player is changed. If there's no player, return an observable that never emits.
    (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.switchMap)(player => {
      return player ? (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.fromEventPattern)(listener => {
        player.addEventListener(name, listener);
      }, listener => {
        // The API seems to throw when we try to unbind from a destroyed player and it doesn't
        // expose whether the player has been destroyed so we have to wrap it in a try/catch to
        // prevent the entire stream from erroring out.
        try {
          if (player.removeEventListener) {
            player.removeEventListener(name, listener);
          }
        } catch {}
      }) : (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.of)();
    }), // By default we run all the API interactions outside the zone
    // so we have to bring the events back in manually when they emit.
    source => new rxjs__WEBPACK_IMPORTED_MODULE_11__.Observable(observer => source.subscribe({
      next: value => this._ngZone.run(() => observer.next(value)),
      error: error => observer.error(error),
      complete: () => observer.complete()
    })), // Ensures that everything is cleared out on destroy.
    (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.takeUntil)(this._destroyed));
  }

}

YouTubePlayer.ɵfac = function YouTubePlayer_Factory(t) {
  return new (t || YouTubePlayer)(_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_12__.NgZone), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_12__.PLATFORM_ID));
};

YouTubePlayer.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdefineComponent"]({
  type: YouTubePlayer,
  selectors: [["youtube-player"]],
  viewQuery: function YouTubePlayer_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵviewQuery"](_c0, 5);
    }

    if (rf & 2) {
      let _t;

      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵloadQuery"]()) && (ctx.youtubeContainer = _t.first);
    }
  },
  inputs: {
    videoId: "videoId",
    height: "height",
    width: "width",
    startSeconds: "startSeconds",
    endSeconds: "endSeconds",
    suggestedQuality: "suggestedQuality",
    playerVars: "playerVars",
    showBeforeIframeApiLoads: "showBeforeIframeApiLoads"
  },
  outputs: {
    ready: "ready",
    stateChange: "stateChange",
    error: "error",
    apiChange: "apiChange",
    playbackQualityChange: "playbackQualityChange",
    playbackRateChange: "playbackRateChange"
  },
  decls: 2,
  vars: 0,
  consts: [["youtubeContainer", ""]],
  template: function YouTubePlayer_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](0, "div", null, 0);
    }
  },
  encapsulation: 2,
  changeDetection: 0
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵsetClassMetadata"](YouTubePlayer, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.Component,
    args: [{
      selector: 'youtube-player',
      changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_12__.ChangeDetectionStrategy.OnPush,
      encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_12__.ViewEncapsulation.None,
      // This div is *replaced* by the YouTube player embed.
      template: '<div #youtubeContainer></div>'
    }]
  }], function () {
    return [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.NgZone
    }, {
      type: Object,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.Inject,
        args: [_angular_core__WEBPACK_IMPORTED_MODULE_12__.PLATFORM_ID]
      }]
    }];
  }, {
    videoId: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.Input
    }],
    height: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.Input
    }],
    width: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.Input
    }],
    startSeconds: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.Input
    }],
    endSeconds: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.Input
    }],
    suggestedQuality: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.Input
    }],
    playerVars: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.Input
    }],
    showBeforeIframeApiLoads: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.Input
    }],
    ready: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.Output
    }],
    stateChange: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.Output
    }],
    error: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.Output
    }],
    apiChange: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.Output
    }],
    playbackQualityChange: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.Output
    }],
    playbackRateChange: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.Output
    }],
    youtubeContainer: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.ViewChild,
      args: ['youtubeContainer']
    }]
  });
})();
/** Listens to changes to the given width and height and sets it on the player. */


function bindSizeToPlayer(playerObs, widthObs, heightObs) {
  return (0,rxjs__WEBPACK_IMPORTED_MODULE_13__.combineLatest)([playerObs, widthObs, heightObs]).subscribe(([player, width, height]) => player && player.setSize(width, height));
}
/** Listens to changes from the suggested quality and sets it on the given player. */


function bindSuggestedQualityToPlayer(playerObs, suggestedQualityObs) {
  return (0,rxjs__WEBPACK_IMPORTED_MODULE_13__.combineLatest)([playerObs, suggestedQualityObs]).subscribe(([player, suggestedQuality]) => player && suggestedQuality && player.setPlaybackQuality(suggestedQuality));
}
/**
 * Returns an observable that emits the loaded player once it's ready. Certain properties/methods
 * won't be available until the iframe finishes loading.
 * @param onAbort Callback function that will be invoked if the player loading was aborted before
 * it was able to complete. Can be used to clean up any loose references.
 */


function waitUntilReady(onAbort) {
  return (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.mergeMap)(player => {
    if (!player) {
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.of)(undefined);
    }

    if (playerIsReady(player)) {
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.of)(player);
    } // Since removeEventListener is not on Player when it's initialized, we can't use fromEvent.
    // The player is not initialized fully until the ready is called.


    return new rxjs__WEBPACK_IMPORTED_MODULE_11__.Observable(emitter => {
      let aborted = false;
      let resolved = false;

      const onReady = event => {
        resolved = true;

        if (!aborted) {
          event.target.removeEventListener('onReady', onReady);
          emitter.next(event.target);
        }
      };

      player.addEventListener('onReady', onReady);
      return () => {
        aborted = true;

        if (!resolved) {
          onAbort(player);
        }
      };
    }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.take)(1), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.startWith)(undefined));
  });
}
/** Create an observable for the player based on the given options. */


function createPlayerObservable(youtubeContainer, videoIdObs, iframeApiAvailableObs, widthObs, heightObs, playerVarsObs, ngZone) {
  const playerOptions = (0,rxjs__WEBPACK_IMPORTED_MODULE_13__.combineLatest)([videoIdObs, playerVarsObs]).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.withLatestFrom)((0,rxjs__WEBPACK_IMPORTED_MODULE_13__.combineLatest)([widthObs, heightObs])), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.map)(([constructorOptions, sizeOptions]) => {
    const [videoId, playerVars] = constructorOptions;
    const [width, height] = sizeOptions;
    return videoId ? {
      videoId,
      playerVars,
      width,
      height
    } : undefined;
  }));
  return (0,rxjs__WEBPACK_IMPORTED_MODULE_13__.combineLatest)([youtubeContainer, playerOptions, (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.of)(ngZone)]).pipe(skipUntilRememberLatest(iframeApiAvailableObs), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_17__.scan)(syncPlayerState, undefined), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_18__.distinctUntilChanged)());
}
/** Skips the given observable until the other observable emits true, then emit the latest. */


function skipUntilRememberLatest(notifier) {
  return (0,rxjs__WEBPACK_IMPORTED_MODULE_19__.pipe)((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_20__.combineLatest)(notifier), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_21__.skipWhile)(([_, doneSkipping]) => !doneSkipping), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.map)(([value]) => value));
}
/** Destroy the player if there are no options, or create the player if there are options. */


function syncPlayerState(player, [container, videoOptions, ngZone]) {
  if (player && videoOptions && player.playerVars !== videoOptions.playerVars) {
    // The player needs to be recreated if the playerVars are different.
    player.destroy();
  } else if (!videoOptions) {
    if (player) {
      // Destroy the player if the videoId was removed.
      player.destroy();
    }

    return;
  } else if (player) {
    return player;
  } // Important! We need to create the Player object outside of the `NgZone`, because it kicks
  // off a 250ms setInterval which will continually trigger change detection if we don't.


  const newPlayer = ngZone.runOutsideAngular(() => new YT.Player(container, videoOptions));
  newPlayer.videoId = videoOptions.videoId;
  newPlayer.playerVars = videoOptions.playerVars;
  return newPlayer;
}
/**
 * Call cueVideoById if the videoId changes, or when start or end seconds change. cueVideoById will
 * change the loaded video id to the given videoId, and set the start and end times to the given
 * start/end seconds.
 */


function bindCueVideoCall(playerObs, videoIdObs, startSecondsObs, endSecondsObs, suggestedQualityObs, destroyed) {
  const cueOptionsObs = (0,rxjs__WEBPACK_IMPORTED_MODULE_13__.combineLatest)([startSecondsObs, endSecondsObs]).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.map)(([startSeconds, endSeconds]) => ({
    startSeconds,
    endSeconds
  }))); // Only respond to changes in cue options if the player is not running.

  const filteredCueOptions = cueOptionsObs.pipe(filterOnOther(playerObs, player => !!player && !hasPlayerStarted(player))); // If the video id changed, there's no reason to run 'cue' unless the player
  // was initialized with a different video id.

  const changedVideoId = videoIdObs.pipe(filterOnOther(playerObs, (player, videoId) => !!player && player.videoId !== videoId)); // If the player changed, there's no reason to run 'cue' unless there are cue options.

  const changedPlayer = playerObs.pipe(filterOnOther((0,rxjs__WEBPACK_IMPORTED_MODULE_13__.combineLatest)([videoIdObs, cueOptionsObs]), ([videoId, cueOptions], player) => !!player && (videoId != player.videoId || !!cueOptions.startSeconds || !!cueOptions.endSeconds)));
  (0,rxjs__WEBPACK_IMPORTED_MODULE_22__.merge)(changedPlayer, changedVideoId, filteredCueOptions).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.withLatestFrom)((0,rxjs__WEBPACK_IMPORTED_MODULE_13__.combineLatest)([playerObs, videoIdObs, cueOptionsObs, suggestedQualityObs])), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.map)(([_, values]) => values), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.takeUntil)(destroyed)).subscribe(([player, videoId, cueOptions, suggestedQuality]) => {
    if (!videoId || !player) {
      return;
    }

    player.videoId = videoId;
    player.cueVideoById({
      videoId,
      suggestedQuality,
      ...cueOptions
    });
  });
}

function hasPlayerStarted(player) {
  const state = player.getPlayerState();
  return state !== YT.PlayerState.UNSTARTED && state !== YT.PlayerState.CUED;
}

function playerIsReady(player) {
  return 'getPlayerStatus' in player;
}
/** Combines the two observables temporarily for the filter function. */


function filterOnOther(otherObs, filterFn) {
  return (0,rxjs__WEBPACK_IMPORTED_MODULE_19__.pipe)((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.withLatestFrom)(otherObs), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_23__.filter)(([value, other]) => filterFn(other, value)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.map)(([value]) => value));
}
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */


const COMPONENTS = [YouTubePlayer];

class YouTubePlayerModule {}

YouTubePlayerModule.ɵfac = function YouTubePlayerModule_Factory(t) {
  return new (t || YouTubePlayerModule)();
};

YouTubePlayerModule.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdefineNgModule"]({
  type: YouTubePlayerModule,
  declarations: [YouTubePlayer],
  exports: [YouTubePlayer]
});
YouTubePlayerModule.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdefineInjector"]({});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵsetClassMetadata"](YouTubePlayerModule, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.NgModule,
    args: [{
      declarations: COMPONENTS,
      exports: COMPONENTS
    }]
  }], null, null);
})();
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Generated bundle index. Do not edit.
 */




/***/ })

}]);
//# sourceMappingURL=src_app_pages_youtube-view_youtube-view_module_ts.js.map