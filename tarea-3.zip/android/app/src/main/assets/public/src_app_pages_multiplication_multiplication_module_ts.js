"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_multiplication_multiplication_module_ts"],{

/***/ 382:
/*!***********************************************************************!*\
  !*** ./src/app/pages/multiplication/multiplication-routing.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MultiplicationPageRoutingModule": () => (/* binding */ MultiplicationPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _multiplication_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./multiplication.page */ 2759);




const routes = [
    {
        path: '',
        component: _multiplication_page__WEBPACK_IMPORTED_MODULE_0__.MultiplicationPage
    }
];
let MultiplicationPageRoutingModule = class MultiplicationPageRoutingModule {
};
MultiplicationPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MultiplicationPageRoutingModule);



/***/ }),

/***/ 9374:
/*!***************************************************************!*\
  !*** ./src/app/pages/multiplication/multiplication.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MultiplicationPageModule": () => (/* binding */ MultiplicationPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8346);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 8099);
/* harmony import */ var _multiplication_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./multiplication-routing.module */ 382);
/* harmony import */ var _multiplication_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./multiplication.page */ 2759);







let MultiplicationPageModule = class MultiplicationPageModule {
};
MultiplicationPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _multiplication_routing_module__WEBPACK_IMPORTED_MODULE_0__.MultiplicationPageRoutingModule
        ],
        declarations: [_multiplication_page__WEBPACK_IMPORTED_MODULE_1__.MultiplicationPage]
    })
], MultiplicationPageModule);



/***/ }),

/***/ 2759:
/*!*************************************************************!*\
  !*** ./src/app/pages/multiplication/multiplication.page.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MultiplicationPage": () => (/* binding */ MultiplicationPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _C_Users_Samy_Desktop_Pruebas_ionic_tarea_3_node_modules_ngtools_webpack_src_loaders_direct_resource_js_multiplication_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./multiplication.page.html */ 6554);
/* harmony import */ var _multiplication_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./multiplication.page.scss */ 5245);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);




let MultiplicationPage = class MultiplicationPage {
    constructor() {
        this.maxValueMult = 13;
        this.value = 12;
        this.numbers = Array(this.maxValueMult).fill(1).map((x, i) => i + 1);
    }
};
MultiplicationPage.ctorParameters = () => [];
MultiplicationPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-multiplication',
        template: _C_Users_Samy_Desktop_Pruebas_ionic_tarea_3_node_modules_ngtools_webpack_src_loaders_direct_resource_js_multiplication_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_multiplication_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], MultiplicationPage);



/***/ }),

/***/ 6554:
/*!******************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/multiplication/multiplication.page.html ***!
  \******************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header [translucent]=\"true\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Multiplicatión</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n  <ion-header collapse=\"condense\">\n    <ion-toolbar>\n      <ion-title size=\"large\">Multiplicatión</ion-title>\n    </ion-toolbar>\n  </ion-header>\n\n  <div class=\"content\">\n    <ion-item>\n      <ion-label position=\"floating\">Table de multiplaicar: </ion-label>\n      <ion-input type=\"number\" [(ngModel)]=\"value\"></ion-input>\n    </ion-item>\n    <div id=\"div-table\" *ngIf=\"value\">\n      <ion-item-group>\n        <ion-item-divider>\n          <ion-label> Table del {{value}}</ion-label>\n        </ion-item-divider>\n\n        <ion-item *ngFor=\"let n of numbers\">\n          <ion-label> {{value}} x {{n}} = {{value * n}}</ion-label>\n        </ion-item>\n      </ion-item-group>\n    </div>\n  </div>\n</ion-content>\n");

/***/ }),

/***/ 5245:
/*!***************************************************************!*\
  !*** ./src/app/pages/multiplication/multiplication.page.scss ***!
  \***************************************************************/
/***/ ((module) => {

module.exports = "#div-table {\n  margin-top: 25px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm11bHRpcGxpY2F0aW9uLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGdCQUFBO0FBQ0oiLCJmaWxlIjoibXVsdGlwbGljYXRpb24ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiI2Rpdi10YWJsZXtcclxuICAgIG1hcmdpbi10b3A6IDI1cHg7XHJcbn0iXX0= */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_multiplication_multiplication_module_ts.js.map