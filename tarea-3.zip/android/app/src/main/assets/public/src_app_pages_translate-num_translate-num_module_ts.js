"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_translate-num_translate-num_module_ts"],{

/***/ 9220:
/*!*********************************************************************!*\
  !*** ./src/app/pages/translate-num/translate-num-routing.module.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TranslateNumPageRoutingModule": () => (/* binding */ TranslateNumPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _translate_num_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./translate-num.page */ 1611);




const routes = [
    {
        path: '',
        component: _translate_num_page__WEBPACK_IMPORTED_MODULE_0__.TranslateNumPage
    }
];
let TranslateNumPageRoutingModule = class TranslateNumPageRoutingModule {
};
TranslateNumPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], TranslateNumPageRoutingModule);



/***/ }),

/***/ 1530:
/*!*************************************************************!*\
  !*** ./src/app/pages/translate-num/translate-num.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TranslateNumPageModule": () => (/* binding */ TranslateNumPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8346);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 8099);
/* harmony import */ var _translate_num_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./translate-num-routing.module */ 9220);
/* harmony import */ var _translate_num_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./translate-num.page */ 1611);







let TranslateNumPageModule = class TranslateNumPageModule {
};
TranslateNumPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _translate_num_routing_module__WEBPACK_IMPORTED_MODULE_0__.TranslateNumPageRoutingModule
        ],
        declarations: [_translate_num_page__WEBPACK_IMPORTED_MODULE_1__.TranslateNumPage]
    })
], TranslateNumPageModule);



/***/ }),

/***/ 1611:
/*!***********************************************************!*\
  !*** ./src/app/pages/translate-num/translate-num.page.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TranslateNumPage": () => (/* binding */ TranslateNumPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _C_Users_Samy_Desktop_Pruebas_ionic_tarea_3_node_modules_ngtools_webpack_src_loaders_direct_resource_js_translate_num_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./translate-num.page.html */ 2297);
/* harmony import */ var _translate_num_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./translate-num.page.scss */ 7280);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _services_translate_num_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/translate-num.service */ 755);





let TranslateNumPage = class TranslateNumPage {
    constructor(translate) {
        this.translate = translate;
        this.value = null;
    }
    change() {
        if (this.value >= 0 && this.value <= 1000000)
            this.result = this.translate.numToStrings(this.value);
        else
            this.result = 'Cantidad no validad';
    }
};
TranslateNumPage.ctorParameters = () => [
    { type: _services_translate_num_service__WEBPACK_IMPORTED_MODULE_2__.TranslateNumService }
];
TranslateNumPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-translate-num',
        template: _C_Users_Samy_Desktop_Pruebas_ionic_tarea_3_node_modules_ngtools_webpack_src_loaders_direct_resource_js_translate_num_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        providers: [_services_translate_num_service__WEBPACK_IMPORTED_MODULE_2__.TranslateNumService],
        styles: [_translate_num_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], TranslateNumPage);



/***/ }),

/***/ 755:
/*!***************************************************!*\
  !*** ./src/app/services/translate-num.service.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "dictionary": () => (/* binding */ dictionary),
/* harmony export */   "TranslateNumService": () => (/* binding */ TranslateNumService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4001);


const dictionary = [
    { id: 1, text: ["uno"], ischange: false },
    { id: 2, text: ["dos"], ischange: false },
    { id: 3, text: ["tres"], ischange: false },
    { id: 4, text: ["cuatro"], ischange: false },
    { id: 5, text: ["cinco"], ischange: false },
    { id: 6, text: ["seis"], ischange: false },
    { id: 7, text: ["siete"], ischange: false },
    { id: 8, text: ["ocho"], ischange: false },
    { id: 9, text: ["nueve"], ischange: false },
    { id: 10, text: ["diez"], ischange: false },
    { id: 11, text: ["once"], ischange: false },
    { id: 12, text: ["doce"], ischange: false },
    { id: 13, text: ["trece"], ischange: false },
    { id: 14, text: ["catorce"], ischange: false },
    { id: 15, text: ["quince"], ischange: false },
    { id: 16, text: ["dieciséis"], ischange: false },
    { id: 17, text: ["diecisiete"], ischange: false },
    { id: 18, text: ["dieciocho"], ischange: false },
    { id: 19, text: ["diecinueve"], ischange: false },
    { id: 20, text: ["veinte", "veinti"], ischange: true },
    { id: 30, text: ["treinta"], ischange: false },
    { id: 40, text: ["cuarenta"], ischange: false },
    { id: 50, text: ["cincuenta"], ischange: false },
    { id: 60, text: ["sesenta"], ischange: false },
    { id: 70, text: ["setenta"], ischange: false },
    { id: 80, text: ["ochenta"], ischange: false },
    { id: 90, text: ["noventa"], ischange: false },
    { id: 100, text: ["cien", "ciento", "cientos"], ischange: true },
    { id: 1000, text: ["mil "], ischange: false },
    { id: 1000000, text: ["un millon "], ischange: false }
];
let TranslateNumService = class TranslateNumService {
    constructor() {
        dictionary.reverse();
    }
    numToStrings(n) {
        let text = '';
        if (n === 0)
            return 'cero';
        dictionary.forEach((x) => {
            if (n >= x.id) {
                let division = ~~(n / x.id);
                console.log(division);
                if (n >= 2000 && n <= 999999) {
                    text += `${this.numToStrings(division)} ${x.text[0]} `;
                }
                else if (n >= 200 && n < 1000) {
                    let t = `${this.numToStrings(division)}${x.text[2]} `;
                    if (5 === division)
                        text += 'quinientos ';
                    else if (9 === division) {
                        text += `nove${x.text[2]} `;
                    }
                    else
                        text += t;
                }
                else if (n > 100 && n < 200) {
                    text += `${x.text[1]} `;
                }
                else if (x.id >= 30 && x.id <= 90 && n % x.id != 0) {
                    text += ` ${x.text[0]} y `;
                }
                else if (x.id == 20 && n > 20) {
                    text += `${x.text[1]}`;
                }
                else if (n % x.id != 0 && x.ischange) {
                    text += `${x.text[1]}`;
                }
                else {
                    text += `${x.text[0]}`;
                }
                n %= x.id;
            }
        });
        return text;
    }
};
TranslateNumService.ctorParameters = () => [];
TranslateNumService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Injectable)({
        providedIn: 'root'
    })
], TranslateNumService);



/***/ }),

/***/ 2297:
/*!****************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/translate-num/translate-num.page.html ***!
  \****************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header [translucent]=\"true\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Numero-Texto</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n  <ion-header collapse=\"condense\">\n    <ion-toolbar>\n      <ion-title size=\"large\">Numero-Texto</ion-title>\n    </ion-toolbar>\n  </ion-header>\n\n  <div class=\"content\">\n    <ion-item>\n      <ion-label>Numero:</ion-label>\n      <ion-input type=\"number\" [(ngModel)]=\"value\" placeholder=\"3\" (ionChange)=\"change()\"></ion-input>\n    </ion-item>\n\n    <div id=\"result\">\n      <p>{{result}}</p>\n    </div>\n  </div>\n</ion-content>\n");

/***/ }),

/***/ 7280:
/*!*************************************************************!*\
  !*** ./src/app/pages/translate-num/translate-num.page.scss ***!
  \*************************************************************/
/***/ ((module) => {

module.exports = "#result {\n  position: absolute;\n  left: 50%;\n  top: 60%;\n  transform: translateY(-50%) translateX(-50%);\n}\n#result p {\n  text-transform: capitalize;\n  font-size: 50px;\n  text-align: center;\n  color: #FF6D00;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRyYW5zbGF0ZS1udW0ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksa0JBQUE7RUFDQSxTQUFBO0VBQ0EsUUFBQTtFQUNBLDRDQUFBO0FBQ0o7QUFDSTtFQUNJLDBCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtBQUNSIiwiZmlsZSI6InRyYW5zbGF0ZS1udW0ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiI3Jlc3VsdHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGxlZnQ6IDUwJTtcclxuICAgIHRvcDogNjAlO1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC01MCUpIHRyYW5zbGF0ZVgoLTUwJSk7XHJcblxyXG4gICAgcHtcclxuICAgICAgICB0ZXh0LXRyYW5zZm9ybTogY2FwaXRhbGl6ZTtcclxuICAgICAgICBmb250LXNpemU6IDUwcHg7XHJcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgIGNvbG9yOiAjRkY2RDAwO1xyXG4gICAgfVxyXG59Il19 */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_translate-num_translate-num_module_ts.js.map