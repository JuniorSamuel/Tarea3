"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_sum_sum_module_ts"],{

/***/ 580:
/*!*************************************************!*\
  !*** ./src/app/pages/sum/sum-routing.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SumPageRoutingModule": () => (/* binding */ SumPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _sum_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./sum.page */ 4567);




const routes = [
    {
        path: '',
        component: _sum_page__WEBPACK_IMPORTED_MODULE_0__.SumPage
    }
];
let SumPageRoutingModule = class SumPageRoutingModule {
};
SumPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SumPageRoutingModule);



/***/ }),

/***/ 6024:
/*!*****************************************!*\
  !*** ./src/app/pages/sum/sum.module.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SumPageModule": () => (/* binding */ SumPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8346);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 8099);
/* harmony import */ var _sum_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./sum-routing.module */ 580);
/* harmony import */ var _sum_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sum.page */ 4567);







let SumPageModule = class SumPageModule {
};
SumPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _sum_routing_module__WEBPACK_IMPORTED_MODULE_0__.SumPageRoutingModule
        ],
        declarations: [_sum_page__WEBPACK_IMPORTED_MODULE_1__.SumPage]
    })
], SumPageModule);



/***/ }),

/***/ 4567:
/*!***************************************!*\
  !*** ./src/app/pages/sum/sum.page.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SumPage": () => (/* binding */ SumPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _C_Users_Samy_Desktop_Pruebas_ionic_tarea_3_node_modules_ngtools_webpack_src_loaders_direct_resource_js_sum_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./sum.page.html */ 7009);
/* harmony import */ var _sum_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sum.page.scss */ 5712);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/storage-angular */ 7897);





let SumPage = class SumPage {
    constructor(storage) {
        this.storage = storage;
        this.operation = '+';
        this.value = { num1: null, num2: null };
        this.results = [];
        this.key = 0;
        this.result = 0;
        this.init();
    }
    save() {
        if (this.value.num1 != null && this.value.num2 != null) { // validamos los datos
            let item = { key: `${++this.key}`, value: `${this.value.num1} ${this.operation} ${this.value.num2} = ${this.getOperation(this.value.num1, this.value.num2)}` };
            this.results.unshift(item);
            this.set(item);
        }
    }
    delete(v) {
        this.results = this.results.filter((x) => x != v);
        this.storage.remove(v.key);
    }
    init() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            const storage = yield this.storage.create();
            this.storage = storage;
            this.key = yield this.getkey();
            storage.forEach((value, key) => {
                this.results.unshift({ key: key, value: value });
            });
        });
    }
    selectButton(op) {
        this.operation = op;
    }
    //Obtenemos en el valor de la ultima llava guardada en el IndexDB
    getkey() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            let lenght = yield this.storage.length();
            ;
            let keys = yield this.storage.keys();
            console.log(keys[lenght - 1] || "0");
            return parseInt(keys[lenght - 1] || "0");
        });
    }
    getOperation(num1, num2) {
        switch (this.operation) {
            case "+":
                return num1 + num2;
            case "-":
                return num1 - num2;
            case "/":
                return num2 !== 0 ? num1 / num2 : 'Indefinido';
            case "x":
                return num1 * num2;
        }
    }
    set(value) {
        var _a;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            yield ((_a = this.storage) === null || _a === void 0 ? void 0 : _a.set(value.key, value.value));
        });
    }
};
SumPage.ctorParameters = () => [
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_3__.Storage }
];
SumPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-sum',
        template: _C_Users_Samy_Desktop_Pruebas_ionic_tarea_3_node_modules_ngtools_webpack_src_loaders_direct_resource_js_sum_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        providers: [],
        styles: [_sum_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], SumPage);



/***/ }),

/***/ 7009:
/*!********************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/sum/sum.page.html ***!
  \********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header [translucent]=\"true\">\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <ion-title>Sumadora</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content [fullscreen]=\"true\">\r\n  <ion-header collapse=\"condense\">\r\n    <ion-toolbar>\r\n      <ion-title size=\"large\">Sumadora</ion-title>\r\n    </ion-toolbar>\r\n  </ion-header>\r\n\r\n  <div class=\"content\">\r\n    <ion-item>\r\n      <ion-grid class=\"p-0\">\r\n        <ion-row class=\"p-0\">\r\n          <ion-col size=\"5\" class=\"p-0\">\r\n            <ion-input\r\n              type=\"number\"\r\n              class=\"p-0\"\r\n              placeholder=\"89\"\r\n              [(ngModel)]=\"value.num1\"\r\n            ></ion-input>\r\n          </ion-col>\r\n          <ion-col size=\"2\" class=\"p-0\">\r\n            <p>{{operation}}</p>\r\n          </ion-col>\r\n          <ion-col size=\"5\" class=\"p-0\">\r\n            <ion-input\r\n              type=\"number\"\r\n              class=\"p-0\"\r\n              placeholder=\"10\"\r\n              [(ngModel)]=\"value.num2\"\r\n            ></ion-input>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ion-item>\r\n\r\n\r\n      <ion-row>\r\n        <ion-col size=\"3\"><ion-button shape=\"round\" (click)=\"selectButton('+')\" [fill]=\" operation === '+' ? 'solid' : 'outline'\">+</ion-button></ion-col>\r\n        <ion-col size=\"3\"><ion-button shape=\"round\" (click)=\"selectButton('-')\" [fill]=\" operation === '-' ? 'solid' : 'outline'\">-</ion-button></ion-col>\r\n        <ion-col size=\"3\"><ion-button shape=\"round\" (click)=\"selectButton('/')\" [fill]=\" operation === '/' ? 'solid' : 'outline'\">/</ion-button></ion-col>\r\n        <ion-col size=\"3\"><ion-button shape=\"round\" (click)=\"selectButton('x')\" [fill]=\" operation === 'x' ? 'solid' : 'outline'\">x</ion-button></ion-col>\r\n      </ion-row>\r\n\r\n   \r\n    <div class=\"result\">\r\n      <p>{{ getOperation(value.num1, value.num2)}}</p>\r\n    </div>\r\n\r\n    \r\n    <ion-button id=\"btn\" expand=\"block\" fill=\"outline\" mode=\"ios\" shape=\"round\" (click)=\"save()\">Registrar</ion-button>\r\n    <ion-list mode=\"ios\">\r\n      <ion-list-header mode=\"ios\">\r\n        Resultado\r\n      </ion-list-header>\r\n      <ion-item *ngFor=\"let r of results; index as i\">\r\n        {{ r.value}}\r\n        <button\r\n          class=\"delete\"\r\n          fill=\"clear\"\r\n          slot=\"end\"\r\n          title=\"eliminar\"\r\n          (click)=\"delete(r)\">\r\n          <ion-icon name=\"trash-outline\"></ion-icon>\r\n        </button>\r\n      </ion-item>\r\n      <ion-item *ngIf=\"!results.length\"> Historial vacio </ion-item>\r\n    </ion-list>\r\n  </div>\r\n</ion-content>\r\n");

/***/ }),

/***/ 5712:
/*!*****************************************!*\
  !*** ./src/app/pages/sum/sum.page.scss ***!
  \*****************************************/
/***/ ((module) => {

module.exports = ".p-0 {\n  padding: 0px;\n}\n\np {\n  width: max-content;\n  height: max-content;\n  font-size: 30px;\n  margin: 0px auto;\n}\n\nion-button {\n  width: 90%;\n  margin: 1px auto;\n  padding: 4px 0px;\n}\n\n#container {\n  margin: 10px 0px 15px 0px;\n}\n\n.delete {\n  background-color: transparent;\n}\n\n.result {\n  margin: 1rem;\n}\n\n.result p {\n  font-size: 80px;\n  font-weight: bold;\n}\n\n#btn {\n  margin-top: 90px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN1bS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxZQUFBO0FBQ0o7O0FBRUE7RUFDSSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FBQ0o7O0FBRUE7RUFDSSxVQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtBQUNKOztBQUVBO0VBQ0kseUJBQUE7QUFDSjs7QUFFQTtFQUNJLDZCQUFBO0FBQ0o7O0FBRUE7RUFDSSxZQUFBO0FBQ0o7O0FBQ0k7RUFDSSxlQUFBO0VBQ0EsaUJBQUE7QUFDUjs7QUFHQTtFQUNJLGdCQUFBO0FBQUoiLCJmaWxlIjoic3VtLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5wLTB7XHJcbiAgICBwYWRkaW5nOiAwcHg7XHJcbn1cclxuXHJcbnB7XHJcbiAgICB3aWR0aDogbWF4LWNvbnRlbnQ7XHJcbiAgICBoZWlnaHQ6IG1heC1jb250ZW50O1xyXG4gICAgZm9udC1zaXplOiAzMHB4O1xyXG4gICAgbWFyZ2luOiAwcHggYXV0bztcclxufVxyXG5cclxuaW9uLWJ1dHRvbntcclxuICAgIHdpZHRoOiA5MCU7XHJcbiAgICBtYXJnaW46IDFweCBhdXRvO1xyXG4gICAgcGFkZGluZzogNHB4IDBweDtcclxufVxyXG5cclxuI2NvbnRhaW5lciB7XHJcbiAgICBtYXJnaW46IDEwcHggMHB4IDE1cHggMHB4O1xyXG59XHJcblxyXG4uZGVsZXRle1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcbn1cclxuXHJcbi5yZXN1bHR7XHJcbiAgICBtYXJnaW46IDFyZW07XHJcblxyXG4gICAgcHtcclxuICAgICAgICBmb250LXNpemU6ODBweDtcclxuICAgICAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIH1cclxufVxyXG5cclxuI2J0bntcclxuICAgIG1hcmdpbi10b3A6IDkwcHg7XHJcbn0iXX0= */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_sum_sum_module_ts.js.map